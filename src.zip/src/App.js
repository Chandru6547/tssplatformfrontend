import Navbar from "./components/Navbar";
import { Routes, Route, Navigate } from "react-router-dom";
import CompilerPage from "./pages/CompilerPage";
import QuestionUploadPage from "./pages/QuestionUploadPage";
import QuestionListPage from "./pages/QuestionListPage";
import SolveQuestionPage from "./pages/SolveQuestionPage";

export default  function App() {
  return (
    <>
      <Navbar />
      <Routes>
        <Route path="/" element={<CompilerPage />} />
        <Route path="/admin/upload" element={<QuestionUploadPage />} />
        <Route path="*" element={<Navigate to="/" />} />
        <Route path="/questions/:id" element={<SolveQuestionPage />} />
        <Route path="/list-question" element={<QuestionListPage />} />
      </Routes>
    </>
  );
}
