import { Link } from "react-router-dom";
import "../pages/CompilerPage.css";

export default function Navbar() {
  return (
    <div style={{
      padding: "12px 20px",
      background: "#020617",
      display: "flex",
      gap: "20px"
    }}>
      <Link to="/" style={{ color: "#fff", textDecoration: "none" }}>
        Compiler
      </Link>
      <Link to="/admin/upload" style={{ color: "#22c55e", textDecoration: "none" }}>
        Upload Question
      </Link>
      <Link to="/list-question" style={{ color: "#22c55e", textDecoration: "none" }}>
        List Questions
      </Link>
    </div>
  );
}
