import { useEffect, useState } from "react";
import { useParams } from "react-router-dom";
import CodeEditor from "../components/CodeEditor";
import "./SolveQuestionPage.css";

export default function SolveQuestionPage() {
  const { id } = useParams();

  const [question, setQuestion] = useState(null);
  const [language, setLanguage] = useState("python");
  const [code, setCode] = useState("");
  const [result, setResult] = useState(null);
  const [loading, setLoading] = useState(false);

  useEffect(() => {
    fetch(`http://localhost:3000/questions/${id}`)
      .then((res) => res.json())
      .then(setQuestion);
  }, [id]);

  const runSample = async () => {
    setLoading(true);
    setResult(null);

    const res = await fetch("http://localhost:3000/run", {
      method: "POST",
      headers: { "Content-Type": "application/json" },
      body: JSON.stringify({
        language,
        code,
        testcases: question.sampleTestcases
      })
    });

    setResult(await res.json());
    setLoading(false);
  };

  const submitHidden = async () => {
    setLoading(true);
    setResult(null);

    const res = await fetch("http://localhost:3000/run", {
      method: "POST",
      headers: { "Content-Type": "application/json" },
      body: JSON.stringify({
        language,
        code,
        questionId: id
      })
    });

    setResult(await res.json());
    setLoading(false);
  };

  if (!question) {
    return <p style={{ padding: 40 }}>Loading question...</p>;
  }

  return (
    <div className="compiler-root">
      <div className="compiler-container solve-layout">

        {/* LEFT PANEL */}
        <div className="solve-left">
          <div className="solve-card">
            <h2 className="solve-title">{question.title}</h2>

            <div
              className="solve-description"
              dangerouslySetInnerHTML={{ __html: question.description }}
            />

            <h3 className="section-heading">Sample Testcases</h3>

            <div className="table-wrapper">
              <table className="sample-table">
                <thead>
                  <tr>
                    <th>#</th>
                    <th>Input</th>
                    <th>Expected Output</th>
                  </tr>
                </thead>
                <tbody>
                  {question.sampleTestcases.map((tc, i) => (
                    <tr key={i}>
                      <td>{i + 1}</td>
                      <td>
                        <pre>{tc.input}</pre>
                      </td>
                      <td>
                        <pre>{tc.output}</pre>
                      </td>
                    </tr>
                  ))}
                </tbody>
              </table>
            </div>

          </div>
        </div>

        {/* RIGHT PANEL */}
        <div className="solve-right">
          <div className="solve-card">

            <div className="editor-top-bar">
              <select
                className="language-select"
                value={language}
                onChange={(e) => setLanguage(e.target.value)}
              >
                <option value="python">Python</option>
                <option value="c">C</option>
                <option value="cpp">C++</option>
                <option value="java">Java</option>
              </select>
            </div>

            <CodeEditor
              language={language}
              code={code}
              setCode={setCode}
            />

            <div className="action-bar">
              <button
                className="action-btn run"
                onClick={runSample}
                disabled={loading}
              >
                ▶ Run
              </button>

              <button
                className="action-btn submit"
                onClick={submitHidden}
                disabled={loading}
              >
                🚀 Submit
              </button>
            </div>
          </div>
        </div>
      </div>

      {/* RESULT */}
      {result && (
        <div className="compiler-container">
          <div className="solve-card result-card">
            {result.error && <div className="fail">{result.error}</div>}

            {result.verdict && (
              <>
                <div
                  className={`verdict ${
                    result.verdict === "AC" ? "pass" : "fail"
                  }`}
                >
                  Verdict: {result.verdict}
                </div>
                <div>
                  Passed {result.passed} / {result.total}
                </div>
              </>
            )}
          </div>
        </div>
      )}
    </div>
  );
}
