import { useEffect, useRef, useState } from "react";
import Quill from "quill";
import "quill/dist/quill.snow.css";
import "./QuestionUploadPage.css";

export default function QuestionUploadPage() {
  const quillContainerRef = useRef(null);
  const quillInstanceRef = useRef(null);

  const [title, setTitle] = useState("");
  const [difficulty, setDifficulty] = useState("Easy");
  const [description, setDescription] = useState("");

  const [sampleTestcases, setSampleTestcases] = useState([
    { input: "", output: "" }
  ]);
  const [hiddenTestcases, setHiddenTestcases] = useState([
    { input: "", output: "" }
  ]);

  const [errors, setErrors] = useState({});
  const [loading, setLoading] = useState(false);
  const [showPopup, setShowPopup] = useState(false);

  useEffect(() => {
    if (!quillInstanceRef.current) {
      quillInstanceRef.current = new Quill(quillContainerRef.current, {
        theme: "snow",
        placeholder: "Describe the problem clearly...",
        modules: {
          toolbar: [
            [{ header: [1, 2, 3, false] }],
            ["bold", "italic"],
            [{ list: "ordered" }, { list: "bullet" }],
            ["code-block"],
            ["link"],
            ["clean"]
          ]
        }
      });

      quillInstanceRef.current.on("text-change", () => {
        setDescription(quillInstanceRef.current.root.innerHTML);
      });
    }
  }, []);

  const update = (list, setList, i, field, value) => {
    const updated = [...list];
    updated[i][field] = value;
    setList(updated);
  };

  /* ---------------- VALIDATION ---------------- */
  const validate = () => {
    const newErrors = {};

    if (!title.trim()) newErrors.title = "Title is required";
    if (!description || description === "<p><br></p>")
      newErrors.description = "Description is required";

    const validSample = sampleTestcases.some(
      (t) => t.input.trim() && t.output.trim()
    );
    if (!validSample)
      newErrors.sampleTestcases =
        "At least one valid sample testcase is required";

    const validHidden = hiddenTestcases.some(
      (t) => t.input.trim() && t.output.trim()
    );
    if (!validHidden)
      newErrors.hiddenTestcases =
        "At least one valid hidden testcase is required";

    setErrors(newErrors);
    return Object.keys(newErrors).length === 0;
  };

  /* ---------------- SUBMIT ---------------- */
  const submit = async () => {
    if (!validate()) return;

    setLoading(true);

    await fetch("http://localhost:3000/questions", {
      method: "POST",
      headers: { "Content-Type": "application/json" },
      body: JSON.stringify({
        title,
        description,
        difficulty,
        sampleTestcases,
        hiddenTestcases
      })
    });

    setLoading(false);
    setShowPopup(true);

    // Reset form
    setTitle("");
    setDifficulty("Easy");
    setDescription("");
    quillInstanceRef.current.root.innerHTML = "";
    setSampleTestcases([{ input: "", output: "" }]);
    setHiddenTestcases([{ input: "", output: "" }]);
    setErrors({});
  };

  return (
    <div className="page-root">
      <div className="main-card">

        <h2 className="page-heading">Create Question</h2>

        {/* TITLE */}
        <div className="form-group">
          <label>Title</label>
          <input
            value={title}
            onChange={(e) => setTitle(e.target.value)}
            placeholder="Enter question title"
          />
          {errors.title && <p className="error-text">{errors.title}</p>}
        </div>

        {/* DIFFICULTY */}
        <div className="form-group">
          <label>Difficulty</label>
          <select
            value={difficulty}
            onChange={(e) => setDifficulty(e.target.value)}
          >
            <option>Easy</option>
            <option>Medium</option>
            <option>Hard</option>
          </select>
        </div>

        {/* DESCRIPTION */}
        <div className="form-group">
          <label>Problem Description</label>
          <div ref={quillContainerRef} className="quill-box" />
          {errors.description && (
            <p className="error-text">{errors.description}</p>
          )}
        </div>

        {/* SAMPLE TESTCASES */}
        <div className="section-title">Sample Testcases</div>

        {sampleTestcases.map((t, i) => (
          <div className="testcase-row" key={i}>
            <textarea
              placeholder="Input"
              value={t.input}
              onChange={(e) =>
                update(sampleTestcases, setSampleTestcases, i, "input", e.target.value)
              }
            />
            <textarea
              placeholder="Output"
              value={t.output}
              onChange={(e) =>
                update(sampleTestcases, setSampleTestcases, i, "output", e.target.value)
              }
            />
          </div>
        ))}

        {errors.sampleTestcases && (
          <p className="error-text">{errors.sampleTestcases}</p>
        )}

        <button
          className="link-btn"
          onClick={() =>
            setSampleTestcases([...sampleTestcases, { input: "", output: "" }])
          }
        >
          + Add Sample Testcase
        </button>

        {/* HIDDEN TESTCASES */}
        <div className="section-title">Hidden Testcases</div>

        {hiddenTestcases.map((t, i) => (
          <div className="testcase-row" key={i}>
            <textarea
              placeholder="Input"
              value={t.input}
              onChange={(e) =>
                update(hiddenTestcases, setHiddenTestcases, i, "input", e.target.value)
              }
            />
            <textarea
              placeholder="Output"
              value={t.output}
              onChange={(e) =>
                update(hiddenTestcases, setHiddenTestcases, i, "output", e.target.value)
              }
            />
          </div>
        ))}

        {errors.hiddenTestcases && (
          <p className="error-text">{errors.hiddenTestcases}</p>
        )}

        <button
          className="link-btn"
          onClick={() =>
            setHiddenTestcases([...hiddenTestcases, { input: "", output: "" }])
          }
        >
          + Add Hidden Testcase
        </button>

        {/* SUBMIT */}
        <div className="footer">
          <button
            className="primary-btn"
            onClick={submit}
            disabled={loading}
          >
            {loading ? "Publishing..." : "Publish Question"}
          </button>
        </div>
      </div>

      {/* SUCCESS POPUP */}
      {showPopup && (
        <div className="popup-overlay">
          <div className="popup-card">
            <h3>✅ Question Created</h3>
            <p>Your question has been published successfully.</p>
            <button
              className="primary-btn"
              onClick={() => setShowPopup(false)}
            >
              OK
            </button>
          </div>
        </div>
      )}
    </div>
  );
}
