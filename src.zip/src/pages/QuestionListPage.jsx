import { useEffect, useState } from "react";
import { useNavigate } from "react-router-dom";
import "./QuestionListPage.css";

export default function QuestionListPage() {
  const [questions, setQuestions] = useState([]);
  const navigate = useNavigate();

  useEffect(() => {
    fetch("http://localhost:3000/questions")
      .then((res) => res.json())
      .then(setQuestions);
  }, []);

  return (
    <div className="ql-page">
      <div className="ql-container">

        {/* HEADER */}
        <div className="ql-header">
          <h1>Practice Problems</h1>
          <p>Sharpen your coding skills with curated problems</p>
        </div>

        {/* GRID */}
        <div className="ql-grid">
          {questions.map((q) => (
            <div className="ql-card" key={q._id}>

              <div className="ql-card-top">
                <h3 className="ql-title">{q.title}</h3>
                <span className={`ql-badge ${q.difficulty.toLowerCase()}`}>
                  {q.difficulty}
                </span>
              </div>

              <div className="ql-card-footer">
                <button
                  className="ql-solve-btn"
                  onClick={() => navigate(`/questions/${q._id}`)}
                >
                  Solve Problem →
                </button>
              </div>

            </div>
          ))}
        </div>

        {/* EMPTY STATE */}
        {questions.length === 0 && (
          <div className="ql-empty">
            <h3>No problems yet</h3>
            <p>Questions will appear here once added.</p>
          </div>
        )}

      </div>
    </div>
  );
}
